<a name="0.3.0"></a>
# [0.3.0](https://github.com/the-darc/string-mask/compare/0.2.2...v0.3.0) (2016-04-02)


### Bug Fixes

* **escape:** don't parse special characters after the recursive portion ([c73e610](https://github.com/the-darc/string-mask/commit/c73e610))

#### Features

* **alphanumeric:** add support to alphanumeric mask ([90447e3](http://github.com/the-darc/string-mask/commit/90447e3))

