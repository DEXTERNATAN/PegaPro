angular.module('pegapro')
  .controller('MainController', MainController);

function MainController($log) {
  $log.debug('[MainController] constructor()');
}
